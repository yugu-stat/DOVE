arma::rowvec BS(double t, arma::vec knots, bool constantVE);

