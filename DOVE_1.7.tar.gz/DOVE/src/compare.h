bool eq(double a, double b);
bool ge(double a, double b);
bool le(double a, double b);

